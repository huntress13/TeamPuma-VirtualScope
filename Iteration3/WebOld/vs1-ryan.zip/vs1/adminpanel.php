<?php require "includes/sessionsconfig.php";

    if($userType != "admin"){
        header("Location: index.php");
    }
?>

<html>
Hello World!
</html>