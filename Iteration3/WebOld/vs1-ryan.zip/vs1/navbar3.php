<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
<div class="container">
  <a class="navbar-brand" href="index.php">VirtualScope</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="viewlivestream.php">Stream</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="viewphoto2.php">Photos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>

    <?php 
        if($loggedIn){
            echo'
            <li class="nav-text">
            '. $username .'
            </li>
            <li class="nav-item">
            <a class="nav-link" href="includes/logout.inc.php">Log Out</a>
            </li>    
        </ul>';
        } else{
            echo'
        <li class="nav-item">
            <a class="nav-link ml-auto" href="loginpage.php">Login</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="signup.php">Sign up</a>
            </li>    
        </ul>';
        }
    ?>
  </div>
</div>  
</nav>