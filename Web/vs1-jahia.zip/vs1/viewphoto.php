<?php
  require 'includes/sessionsconfig.inc.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>VirtualScope</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="styles/photopage-style.css">
  <link rel="stylesheet" href="styles/navbar-style.css">
</head>
<body>

<!-- Navigation -->
<?php include 'navbar.php' ?>

<!-- Content -->
<div class="container">
<div id="viewphoto-jumbo" class="jumbotron text-center">
<h2>Microscope 1 Images</h2>

<div class="container" style="margin-top:30px">

<?php

$dir = 'images';
$filenames = scandir($dir);
$numOfFiles = sizeof($filenames);

for($i = 0; $i < sizeof($filenames)-2; $i++){
    if($i % 3 == 0){ // first of every 3 needs a row
        echo '<div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <a href="'.$dir.'/'.$filenames[$i+2].'" target="_blank">
                            <img class="img-thumbnail img-fluid" src="'.$dir.'/'.$filenames[$i+2].'" style="width:100%">
                        </a>
                        <div>
                            <p>'.$filenames[$i+2].'</p>
                        </div>
                    </div>
                </div>';
    } elseif ($i % 3 == 2){ // End of row needs extra div echoed
        echo '
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <a href="'.$dir.'/'.$filenames[$i+2].'" target="_blank">
                        <img class="img-thumbnail img-fluid" src="'.$dir.'/'.$filenames[$i+2].'" style="width:100%">
                    </a>
                    <div>
                        <p>'.$filenames[$i+2].'</p>
                    </div>
                </div>
            </div>
        </div>';
    } else{
        echo '
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <a href="'.$dir.'/'.$filenames[$i+2].'" target="_blank">
                        <img class="img-thumbnail img-fluid" src="'.$dir.'/'.$filenames[$i+2].'" style="width:100%">
                    </a>
                    <div>
                        <p>'.$filenames[$i+2].'</p>
                    </div>
                </div>
            </div>';
    }
}

if(sizeof($filenames)-2 % 3 != 0){
    echo '</div>';
}

?>

</div>
</div>
</div>
</body>
</html>
